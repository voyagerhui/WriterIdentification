from __future__ import division, print_function
# coding=utf-8
import sys
import os
import glob
import re
import numpy as np

# Keras
from keras.applications.imagenet_utils import preprocess_input, decode_predictions
from keras.models import load_model
from keras.preprocessing import image
from scipy.misc import imread, imresize

# Flask utils
from flask import Flask, json, redirect, url_for, request, render_template
from werkzeug.utils import secure_filename
from gevent.pywsgi import WSGIServer

# Define a flask app
app = Flask(__name__)

# Model saved with Keras model.save()
MODEL_PATH = 'models/mada-ep4808-loss0.484-val_loss0.471.h5'

# Load trained model
model = load_model(MODEL_PATH)
model._make_predict_function()
print('Model loaded. Check http://127.0.0.1:5000/')


def model_predict(img_path, model):
    img_ori = imread(img_path)
    img = img_ori/255
    img = np.reshape(img, [-1, 113, 113, 1])

    probability = model.predict(img)

    top5_index = np.argsort(probability[0])[-1:-6:-1]
    top5_prob = [str(probability[0, top5_index[0]]), str(probability[0, top5_index[1]]),
                 str(probability[0, top5_index[2]]), str(probability[0, top5_index[3]]),
                 str(probability[0, top5_index[4]])]
    top5_indexstr = [str(top5_index[0]+1001), str(top5_index[1]+1001),
                     str(top5_index[2]+1001), str(top5_index[3]+1001),
                     str(top5_index[4]+1001)]

    return top5_indexstr, top5_prob


@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')


@app.route('/predict', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        # Get the file from post request
        f = request.files['file']

        # Save the file to ./uploads
        basepath = os.path.dirname(__file__)
        file_path = os.path.join(
            basepath, 'uploads', secure_filename(f.filename))
        f.save(file_path)

        pic_name = f.filename
        # Make prediction
        top5_index, top5_prob = model_predict(file_path, model)
        wr_dict = {"index1":top5_index[0], "prob1":top5_prob[0],
                   "index2":top5_index[1], "prob2":top5_prob[1],
                   "index3":top5_index[2], "prob3":top5_prob[2],
                   "index4":top5_index[3], "prob4":top5_prob[3],
                   "index5":top5_index[4], "prob5":top5_prob[4],
                   "pic_name":pic_name}

        return json.dumps(wr_dict)
    return None

if __name__ == '__main__':
    # app.run(port=5002, debug=True)

    # Serve the app with gevent
    http_server = WSGIServer(('', 5000), app)
    http_server.serve_forever()
