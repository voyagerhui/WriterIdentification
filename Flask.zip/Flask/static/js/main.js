$(document).ready(function () {
    // Init
    $('.image-section').hide();
    $('.loader').hide();
    $('#result').hide();
    $('#value1').hide();

    // Upload Preview
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#imagePreview').css('background-image', 'url(' + e.target.result + ')');
                $('#imagePreview').hide();
                $('#imagePreview').fadeIn(650);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imageUpload").change(function () {
        $('.image-section').show();
        $('#btn-predict').show();
        $('#result').text('');
        $('#result').text('');
        $('#result').hide();
        $('#value1').hide();
        $('#value2').hide();
        $('#value3').hide();
        $('#value4').hide();
        $('#value5').hide();
        readURL(this);
    });

    // Predict
    $('#btn-predict').click(function () {
        var form_data = new FormData($('#upload-file')[0]);
        // Show loading animation
        $(this).hide();
        $('.loader').show();

        $.ajax({
            type: 'POST',
            url: '/predict',
            data: form_data,
            contentType: false,
            cache: false,
            processData: false,
            async: true,
            success: function (data) {
                var data_obj = $.parseJSON(data);
                $('.loader').hide();
                $('#result').fadeIn(600);
                $('#result').text('图像"'+data_obj["pic_name"]+'"的笔迹鉴定结果:');
                $('#value1').fadeIn(600);
                $('#value1').text('编号及概率:'+data_obj["index1"]+'------------'+data_obj["prob1"]);
                $('#value2').fadeIn(600);
                $('#value2').text('编号及概率:'+data_obj["index2"]+'------------'+data_obj["prob2"]);
                $('#value3').fadeIn(600);
                $('#value3').text('编号及概率:'+data_obj["index3"]+'------------'+data_obj["prob3"]);
                $('#value4').fadeIn(600);
                $('#value4').text('编号及概率:'+data_obj["index4"]+'------------'+data_obj["prob4"]);
                $('#value5').fadeIn(600);
                $('#value5').text('编号及概率:'+data_obj["index5"]+'------------'+data_obj["prob5"]);
                console.log('Success!');
            },
        });
    });

});
