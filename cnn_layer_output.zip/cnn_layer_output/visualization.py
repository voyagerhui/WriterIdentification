#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# Author: voyager
# Date: 20190427
# Function: The program is programmed for WriterRecogition(HalfDeepWriter)
#           Prediction codes

import os
import time
import numpy as np
import keras
from keras.models import load_model
from scipy.misc import imread, imresize
import matplotlib.pyplot as plt
from keras.models import Model
from keras import backend as K


if __name__ == '__main__':
    pic_path = str(input("Please input the pic path:"))

    # read in the pic and label
    img_ori = imread(pic_path)
    img = img_ori/255
    img = np.reshape(img, [-1, 113, 113, 1])

    # load the model
    model = load_model("madamodel30000.h5")
    model.summary()

    # get the layers of model
    layer_0 = K.function([model.layers[0].input], [model.layers[0].output])
    f0 = layer_0([img])[0]
    print("f0.name:", model.layers[0].name)
    layer_1 = K.function([model.layers[0].input], [model.layers[1].output])
    f1 = layer_1([img])[0]
    print("f1.name:", model.layers[1].name)
    layer_2 = K.function([model.layers[0].input], [model.layers[2].output])
    f2 = layer_2([img])[0]
    print("f2.name:", model.layers[2].name)
    layer_3 = K.function([model.layers[0].input], [model.layers[3].output])
    f3 = layer_3([img])[0]
    print("f3.name:", model.layers[3].name)
    layer_4 = K.function([model.layers[0].input], [model.layers[4].output])
    f4 = layer_4([img])[0]
    print("f4.name:", model.layers[4].name)
    layer_5 = K.function([model.layers[0].input], [model.layers[5].output])
    f5 = layer_5([img])[0]
    print("f5.name:", model.layers[5].name)
    layer_6 = K.function([model.layers[0].input], [model.layers[6].output])
    f6 = layer_6([img])[0]
    print("f6.name:", model.layers[6].name)
    layer_7 = K.function([model.layers[0].input], [model.layers[7].output])
    f7 = layer_7([img])[0]
    print("f7.name:", model.layers[7].name)
    layer_8 = K.function([model.layers[0].input], [model.layers[8].output])
    f8 = layer_8([img])[0]
    print("f8.name:", model.layers[8].name)
    layer_9 = K.function([model.layers[0].input], [model.layers[9].output])
    f9 = layer_9([img])[0]
    print("f9.name:", model.layers[9].name)
    layer_10 = K.function([model.layers[0].input], [model.layers[10].output])
    f10 = layer_10([img])[0]
    print("f10.name:", model.layers[10].name)
    layer_11 = K.function([model.layers[0].input], [model.layers[11].output])
    f11 = layer_11([img])[0]
    print("f11.name:", model.layers[11].name)
    layer_12 = K.function([model.layers[0].input], [model.layers[12].output])
    f12 = layer_12([img])[0]
    print("f12.name:", model.layers[12].name)
    layer_13 = K.function([model.layers[0].input], [model.layers[13].output])
    f13 = layer_13([img])[0]
    print("f13.name:", model.layers[13].name)

    # f0: conv2d_1
    for _ in range(96):
        show_img = f0[:, :, :, _]
        show_img.shape = [55, 55]
        plt.subplot(12, 8, _ + 1)
        plt.imshow(show_img, cmap='gray')
        plt.axis('off')
    plt.show()

    # f1: max_pooling2d_1
    for _ in range(96):
        show_img = f1[:, :, :, _]
        show_img.shape = [27, 27]
        plt.subplot(12, 8, _ + 1)
        plt.imshow(show_img, cmap='gray')
        plt.axis('off')
    plt.show()

    # f6: conv2d_5
    for _ in range(256):
        show_img = f6[:, :, :, _]
        show_img.shape = [13, 13]
        plt.subplot(16, 16, _ + 1)
        plt.imshow(show_img, cmap='gray')
        plt.axis('off')
    plt.show()

    # f7: max_pooling2d_3
    for _ in range(256):
        show_img = f7[:, :, :, _]
        show_img.shape = [6, 6]
        plt.subplot(16, 16, _ + 1)
        plt.imshow(show_img, cmap='gray')
        plt.axis('off')
    plt.show()

    # f13: dense_3
    print(f11)


